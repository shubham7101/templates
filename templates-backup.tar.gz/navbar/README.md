# Navbar

## navbar-1

![navbar-1-light](./images/navbar-1-light.jpg)

![navbar-1-dark](./images/navbar-1-dark.jpg)

![navbar-1-mobile](./images/navbar-1-mobile.jpg)

![navbar-1-desktop](./images/navbar-1-desktop.jpg)

This site is hosted. See [Demo](https://templatos.netlify.app/navbar/navbar-1).

`wget https://raw.githubusercontent.com/Shubham-md786/templates/main/navbar/navbar-1.html`

## navbar-2

![navbar-2](./images/navbar-2.jpg)

This site is hosted. See [Demo](https://templatos.netlify.app/navbar/navbar-2).

`wget https://raw.githubusercontent.com/Shubham-md786/templates/main/navbar/navbar-2.html`

## navbar-3

![navbar-3](./images/navbar-3.jpg)

This site is hosted. See [Demo](https://templatos.netlify.app/navbar/navbar-3).

`wget https://raw.githubusercontent.com/S
hubham-md786/templates/main/navbar/navbar
-3.html`
