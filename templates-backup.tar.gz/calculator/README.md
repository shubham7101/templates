# Calculator

## calculator-1

![calculator-1](./images/calculator-1.jpg)

This site is hosted. See [Demo](https://templatos.netlify.app/calculator/calculator-1).

`wget https://raw.githubusercontent.com/Shubham-md786/templates/main/calculator/calculator-1.html`
