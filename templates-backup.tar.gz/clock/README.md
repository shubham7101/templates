# Clock

## clock-1.html

![clock-1-1](./images/clock-1-1.jpg)

![clock-1-2](./images/clock-1-2.jpg)

This site is hosted. See [Demo](https://templatos.netlify.app/clock/clock-1).

`wget https://raw.githubusercontent.com/Shubham-md786/templates/main/clock/clock-1.html`

## stopwatch-1.html

![stopwatch-1](./images/stopwatch-1.jpg)

This site is hosted. See [Demo](https://templatos.netlify.app/clock/stopwatch-1).

`wget https://raw.githubusercontent.com/Shubham-md786/templates/main/clock/stopwatch-1.html`
