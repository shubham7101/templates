# Sidebar

## sidebar-1

![sidebar-1-1](./images/sidebar-1-1.jpg)

![sidebar-1-2](./images/sidebar-1-2.jpg)

This site is hosted. See [Demo](https://templatos.netlify.app/sidebar/sidebar-1).

`wget https://raw.githubusercontent.com/Shubham-md786/templates/main/sidebar/sidebar-1.html`

## sidebar-2

![sidebar-2-light](./images/sidebar-2-light.jpg)

![sidebar-2-dark](./images/sidebar-2-dark.jpg)

This site is hosted. See [Demo](https://templatos.netlify.app/sidebar/sidebar-2).

`wget https://raw.githubusercontent.com/Shubham-md786/templates/main/sidebar/sidebar-2.html`
