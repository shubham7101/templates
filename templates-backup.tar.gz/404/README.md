# 404

## 404-1.html

![404-1](./images/404-1.jpg)

This site is hosted. See [Demo](https://templatos.netlify.app/404/404-1).

`wget https://raw.githubusercontent.com/Shubham-md786/templates/main/404/404-1.html`
